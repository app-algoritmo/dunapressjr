# Cookie Notice

---

## Your Privacy Matters

Boreal Times uses cookies and similar technologies to ensure the proper functioning of our website, enhance your experience, and deliver content that is relevant to you. This Cookie Notice explains how and why we use cookies and how you can manage your preferences.

By clicking **"Accept All"**, you agree to the use of all cookies. You can also click **"Cookie Settings"** to choose which categories of cookies you consent to. If you click **"Ask me later"**, only essential cookies will remain active and your preferences will be stored for the next 24 hours.

---

## Cookie Categories

### 1. Strictly Necessary Cookies

These cookies are essential for the website to function correctly and cannot be disabled. They enable:

- Secure login sessions
- Shopping cart functionality
- Form progress and transactions
- Consistent page display
- Basic system performance analytics

### 2. Functional Cookies

These enhance your experience by:

- Remembering your preferences (language, region, etc.)
- Supporting social media sharing and interaction
- Enabling personalised features (comments, saved articles, etc.)

### 3. Analytics & Performance Cookies

These help us anonymously understand how visitors use the site so we can continually improve performance and user experience.

### 4. Advertising & Targeting Cookies

Used by us and trusted partners to deliver relevant advertising based on your interests. These may track activity across websites.

---

## Manage Your Preferences

You can change or withdraw your consent at any time via the [Cookie Settings] link in the footer. For full details on how we handle personal data, please read our [Privacy Policy].

---

> **Note:** We fully comply with all applicable data-protection laws, including the General Data Protection Regulation (**GDPR**) and Brazil's Lei Geral de Proteção de Dados (**LGPD**). Your data is collected only with explicit consent and is stored securely.

---

*© Boreal Times | AP Gruppen. All rights reserved.*
