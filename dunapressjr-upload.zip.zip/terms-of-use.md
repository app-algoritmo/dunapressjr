# Terms of Use

---

## 1. Acceptance of Terms

Welcome to the Boreal Times website and associated digital services (collectively the **"Site"**). By accessing or using the Site — including articles, software, multimedia content, forums, newsletters, and any other services — you agree to be bound by these Terms of Use and our [Privacy Policy]. We may update these Terms at any time. The revised version becomes effective immediately upon posting.

---

## 2. Use of Content

All content on the Site is protected by copyright and other intellectual property laws. You may view, download, and print materials for personal, non-commercial, informational use only. Any reproduction, redistribution, modification, public display, or commercial exploitation requires prior written permission from Boreal Times.

---

## 3. User-Generated Content

If you submit comments, articles, images, or any other content, you represent that you own or have the necessary rights to it. By submitting, you grant Boreal Times a perpetual, irrevocable, worldwide, royalty-free licence to use, reproduce, modify, publish, and distribute the content in any form or medium.

---

## 4. Prohibited Conduct

You agree not to:

- Post illegal, defamatory, harassing, hateful, or otherwise objectionable material
- Infringe intellectual property, privacy, or publicity rights of others
- Upload viruses, malware, or any harmful code
- Attempt to gain unauthorised access to the Site or its systems
- Use automated tools (bots, scrapers, etc.) to collect content without permission
- Engage in spamming or phishing

---

## 5. User Accounts

If you create an account, you are solely responsible for maintaining the confidentiality of your credentials and for all activities under your account. Notify us immediately of any unauthorised use.

---

## 6. Third-Party Links and Services

The Site may contain links to external websites or services. Boreal Times is not responsible for their availability, content, or privacy practices.

---

## 7. Termination

We reserve the right to suspend or terminate your access to the Site, with or without notice, for any violation of these Terms or for any other reason.

---

## 8. Disclaimers and Limitation of Liability

The Site and its content are provided **"as is"** and **"as available"** without warranties of any kind, express or implied. To the fullest extent permitted by law, Boreal Times disclaims all liability for any damages arising from your use of the Site or reliance on its content.

---

## 9. Governing Law and Jurisdiction

These Terms are governed by the laws of Norway. Any dispute arising from these Terms or your use of the Site shall be submitted exclusively to the competent courts in Oslo, Norway.

---

## 10. Contact Information

Questions about these Terms should be directed through our [Contact Form].

---

*© 2026 Boreal Times | AP Gruppen. All rights reserved.*

**Last updated:** April 2026
