# Privacy Policy

**Last updated:** April 2026

---

## Respect for Your Privacy

Boreal Times, operated by AP Gruppen, and its affiliates (collectively **"Boreal Times"**, **"we"**, **"us"**, or **"our"**) is fully committed to protecting your privacy and handling your personal data responsibly. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you interact with any of our channels, including websites, applications, social media pages, newsletters, offline activities, and marketing campaigns (collectively, the **"Channels"**).

---

## Scope and External Links

Our Channels may contain links to third-party websites, services, or platforms. We are not responsible for the privacy practices of those third parties. We encourage you to read their privacy policies before submitting any personal data.

---

## Information We Collect

Through your use of our Channels we may collect:

- **Personal Information:** name, email address, postal address, telephone number, company/organisation, job title, and interests.
- **Technical and Usage Data:** IP address, device and browser information, geolocation data, browsing behaviour, and analytics data.

We may combine this information for analytical or personalisation purposes. When combined data can identify you, we treat it as personal data.

---

## Use and Sharing of Personal Information

We use and share your personal data only for legitimate purposes, including to:

- Deliver and improve our services and content
- Process transactions and subscriptions
- Provide customer support and respond to inquiries
- Send newsletters, updates, and marketing communications (only with your consent or where permitted by law)
- Personalise your experience
- Operate and secure our Channels
- Conduct analytics and research
- Comply with legal obligations or protect our rights
- Work with trusted third-party service providers acting under strict confidentiality agreements

---

## Cookies and Tracking Technologies

We use cookies and similar technologies to ensure site functionality, analyse performance, and (where you consent) deliver personalised content and advertising. Full details and management options are available in our [Cookie Notice].

---

## Your Rights and Choices

Depending on your location, you have the right to:

- Access, correct, update, or delete your personal data
- Object to or restrict certain processing
- Withdraw consent at any time
- Opt out of marketing communications (via unsubscribe links or your account settings)
- Lodge a complaint with a supervisory authority

To exercise any of these rights, please use our [Contact Form] or the [Data Request] link in the footer.

---

## Children's Privacy

Our Channels are not intended for individuals under 18 years of age. We do not knowingly collect personal data from minors. If you become aware that a minor has provided us with personal data, please contact us immediately so we can delete it.

---

## Data Retention

We keep personal data only for as long as necessary for the purposes set out in this Policy or as required by law. When no longer needed, data is securely deleted or anonymised.

---

## Security Measures

We implement appropriate physical, technical, and organisational measures (including SSL encryption) to protect your personal data against unauthorised access, loss, or misuse.

---

## International Data Transfers

Your data may be processed in countries outside your jurisdiction (including Norway, the EU/EEA, Brazil, and the United States). We ensure appropriate safeguards, such as Standard Contractual Clauses, are in place.

---

## Contact Us

For any questions, requests, or concerns regarding this Privacy Policy or our data practices, please reach us via the [Contact Form] on our website.

---

*© Boreal Times | AP Gruppen. All rights reserved.*
