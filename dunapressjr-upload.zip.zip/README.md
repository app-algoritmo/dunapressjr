# borealtimes
Independent bilingual media hub linking to YouTube (English &amp; Portuguese) and Substack. 
